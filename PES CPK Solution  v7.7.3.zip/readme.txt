# PES CPK Solution v7.7.3 CRACKED

## IMPORTANT
Even if the app perfectly works with internet access, my advice to you is to block the app's internet access through a firewall OR disable internet. Why? Because MjTs-140914 is collecting personal informations using the app. It collects the following(and not only): ISP Provider, IP address, Country, Date, Geolocation, Number of HDD's, Serials for HDD, MB, HOSTNAME.. etc. Thus, i repeat, i strongly suggest to block internet access to this app.

## How to Use
Just run the program and profit ;)

## FAQ
Q: The app doesn't produce any CPK and it gets stuck at one step
A: You need to execute "Visual C++ Redistributable Runtimes All-in-One.url", download and install runtime library

## Copyright
This app was cracked by JohnnyUSA from (cpkprotectiontoolkit.github.io). If you want more cracked apps or you're interested in locking/unlocking toold, please contact me using the website contact options.